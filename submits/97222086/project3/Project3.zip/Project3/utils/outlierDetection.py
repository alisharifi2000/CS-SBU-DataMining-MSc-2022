from prophet import Prophet
import pandas as pd
from statsmodels.tsa.ar_model import AutoReg



def non_timeSeries(data):

    #method1

    outliers1 = []
    up = data.mean() + 3 * data.std()
    low = data.mean() - 3 * data.std()
    temp = (data > up) | (data < low)
    t = data[temp]
    outliers1 = ['True' if x is True else "False" for x in t['feature']]

    #method2-IQR

    outliers2 = []
    Q1 = data.quantile(0.4)
    Q3 = data.quantile(0.6)
    IQR = Q3 - Q1
    temp = ((data < (Q1 - 1.5 * IQR)) | (data > (Q3 + 1.5 * IQR)))
    for i in range(len(data)):
        if (temp['feature'].iloc[i] == False):
            outliers2.append('false')
        else:
            outliers2.append('true')


    data['method1'] = outliers1
    data['method2'] = outliers2
    out = data.reset_index().to_json()
    out = {'data': out}
    return out

def timeSeries(data, vol):

    #prophetMethod
    #
    # outliers1 = ['false' for i in range(len(vol))]
    # model = Prophet()
    # df = data.copy()
    # df.time = pd.to_datetime(df.time)
    # df.columns = ['ds', 'y']
    # model.fit(df)
    # test = pd.DataFrame(df['ds'])
    # forecast = model.predict(test)
    # for i in range(0, len(vol)):
    #     if(forecast['yhat_lower'].iloc[i] < df['y'].iloc[i] < forecast['yhat_upper'].iloc[i]):
    #         outliers1[i] = 'false'
    #     else : outliers1[i] = 'true'

    data = data.set_index(data.time).drop('time', axis=1)
    model = AutoReg(vol, lags=len(vol) // 3)
    model_fit = model.fit()
    predictions = model_fit.predict(start=0, end=len(vol))
    print(predictions)
    outliers1 = ['false' for i in range(len(vol))]
    for i in range(len(vol)):
        if ((predictions[i+1] > vol[i]+vol[i]*2.5) or (predictions[i+1] < vol[i]-vol[i]*2.5)) :
            outliers1[i] = 'true'

    #method2
    outliers2 = []
    #data = data.set_index(data.time).drop('time', axis=1)
    Q1 = data.quantile(0.4)
    Q3 = data.quantile(0.6)
    IQR = Q3 - Q1
    temp = ((data < (Q1 - 1.5 * IQR)) | (data > (Q3 + 1.5 * IQR)))
    for i in range(len(data)):
        if (temp['vol'].iloc[i] == False):
            outliers2.append('false')
        else:
            outliers2.append('true')

    data['method1'] = outliers1
    data['method2'] = outliers2
    out = data.reset_index().to_json()
    out = {'data': out}
    return out

