def make_balance(data, config):
    import pandas as pd
    if config.method == 'SMOTE':
        min_num = data['class'].value_counts().values[-1]
        if min_num <= 1:
            data = data.append(data[data['class'] == config.minor_class], ignore_index=True)
        from imblearn.over_sampling import SMOTE
        oversample = SMOTE(k_neighbors=min(min_num, 6))
        X, y = oversample.fit_resample(data.drop(['class', 'id'], axis=1), data['class'])

    elif config['method']== 'Oversampling':
        from imblearn.over_sampling import RandomOverSampler
        ros = RandomOverSampler(random_state=1)
        X, y = ros.fit_resample(data.drop(['class', 'id'], axis=1), data['class'])

    elif config['method'] == 'Undersampling':
        from imblearn.under_sampling import RandomUnderSampler
        rus = RandomUnderSampler(random_state=1)
        X, y = rus.fit_resample(data.drop(['class', 'id'], axis=1), data['class'])

    elif config.method == 'Clustercentroids':
        from imblearn.under_sampling import ClusterCentroids
        cc = ClusterCentroids()
        X, y = cc.fit_resample(data.drop(['class', 'id'], axis=1), data['class'])

    X['class'] = y
    X['id'] = X.index.to_numpy() + 1

    out = pd.DataFrame(X, columns=data.columns)
    out = out.reset_index().to_json()
    out = {'data': out}
    return out